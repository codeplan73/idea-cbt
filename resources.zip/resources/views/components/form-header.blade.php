<!-- components/form-header.blade.php -->
<div class="row g-0">
    <div class="col-lg-12 pe-lg-2">
        <div class="card mb-3">
            <div class="card-body">
                <div class="row flex-between-center">
                    <div class="col-md">
                        <h5 class="mb-2 mb-md-0">{{ $title }}</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
