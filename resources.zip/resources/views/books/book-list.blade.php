@extends('layouts.app')

@section('content')
    <h1>Student View List of Books</h1>
@endsection
