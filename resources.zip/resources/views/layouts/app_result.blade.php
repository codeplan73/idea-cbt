<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <title> {{ $systemSetup->school_name }}</title>
    <meta name="description"
        content="As an international school we are proud to provide the highest possible standard of education to our students, enabling them to compete in an increasingly competitive global environment.">
    <meta name="viewport" content="width=device-width, initial-scale=0">
    <link href={{ asset('css/main.css ') }} rel='stylesheet' type='text/css'>
</head>

<body>
    @yield('content')
</body>

</html>
